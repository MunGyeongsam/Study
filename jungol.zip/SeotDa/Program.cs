﻿
namespace SeotDa
{
    class Program
    {
        static void Main()
        {
            //OopApproach.Game.Run();
            ProcedualApproch.Run();
        }
    }
}
