﻿
//* csc.exe (C:\Windows\Microsoft.NET\Framework64\v4.0.30319)

// C# 1.0	.NET Framework 1.0/1.1	Visual Studio .NET 2002	First release of C#
// C# 2.0	.NET Framework 2.0	    Visual Studio 2005	
// C# 3.0	.NET Framework 3.0\3.5	Visual Studio 2008	
// C# 4.0	.NET Framework 4.0	    Visual Studio 2010	
// C# 5.0	.NET Framework 4.5	    Visual Studio 2012/2013	
// C# 6.0	.NET Framework 4.6	    Visual Studio 2013/2015	
//C# 7.0	.NET Core	            Visual Studio 2017


namespace Jongol.Days
{
    class Day01
    {
        public static void Run()
        {
            System.Console.WriteLine("Hello Wordl!");
            //System.Console.Read();
        }
    }
}
//*/

/*
// 1. variable
// 2. function(method)
// 3. branch
// 4. loop
// 5. data structure

type

 */
