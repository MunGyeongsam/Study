﻿using System;

namespace Jungol
{
    static class Blabla
	{
		
		public static void Test()
        {
        }
    }
}
