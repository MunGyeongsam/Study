﻿
namespace SevenPoker
{
    class Program
    {
        static void Main()
        {
            Game.Run();
        }
    }
}
